import{a as t}from"../chunks/BYP3CGfV.js";export{t as start};
